# AntennaSleep
Automatic antenna extension after "snooze". Useful for reentry with CommNet.
